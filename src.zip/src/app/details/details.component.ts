import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';


@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  arr:any=[]

  constructor(private serve:UserserviceService) { }

  ngOnInit(): void {
    this.assign()
  }

  assign(){
    debugger;
 this.serve.add().subscribe((data)=>{
   console.log('arr',data)
   this.arr.push({data})
   console.log(this.arr.length)
  //  for (let i = 0; i < this.arr; i++) {
    
  // }
  
})
}
}
