import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  array:any
  project:any={}
  p:any;
  assignments:any
todoList:any
todoListTask:any
complete:any
progress:any
assignment_id:any
  router: any;

  constructor(private user:UserserviceService) { }

  ngOnInit(): void {
    this.add()
    // this.todoList
    // this.complete
    // this.progress 
  
  }
  arrdata: any
  add(){
    debugger;
    this.user.getData().subscribe((data:any) =>{
     this.array=data
     console.log(this.array.data)
     this.arrdata = this.array.data
     this.todoList = this.arrdata.filter((item:any) => item.assignment_name === 'To Do')
     this.complete = this.arrdata.filter((item:any) => item.assignment_name === 'Completed')
     this.progress = this.arrdata.filter((item:any) => item.assignment_name === 'Inprogress')
   
     console.log('ToDoList',this.todoList)
   console.log('Complete',this.complete)
   console.log('Progress',this.progress)
    })
  }
  Todo(data:any){
    debugger;
    this.todoListTask = data.tasks
  this.assignment_id = data.id
localStorage.setItem('Data',JSON.stringify(this.todoListTask))
localStorage.setItem('assignment_id',this.assignment_id)
  console.log('To Do Tasks',this.todoListTask)
  //this.router.navigate(['details']);
    
  }
prog(){

}
comp(){

}
}
